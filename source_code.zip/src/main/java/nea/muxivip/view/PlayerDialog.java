package nea.muxivip.view;
import android.app.*;
import nea.muxivip.ui.*;
import nea.muxivip.*;
import android.widget.*;
import android.media.*;
import android.os.*;
import java.io.*;
import android.view.*;
import android.preference.*;
import android.content.*;
import android.net.*;
import java.net.*;
import nea.muxivip.api.*;

public class PlayerDialog extends Dialog
implements MediaPlayer.OnPreparedListener, Runnable,
SeekBar.OnSeekBarChangeListener, View.OnClickListener,
MediaPlayer.OnCompletionListener, DialogInterface.OnCancelListener
{
	public Activity activity;
	Button downloadButton;
	TextView timeView, titleView;
	SeekBar seekBar;
	MediaPlayer media;
	ImageButton playButton;
	long musicId;
	String title;
	public boolean running = true;

	public PlayerDialog(Activity context)
	{
		super(context);
		Window window = getWindow();
		window.requestFeature(Window.FEATURE_NO_TITLE);
		setCanceledOnTouchOutside(false);
		activity = context;
		setContentView(R.layout.dialog_player);
		setOnCancelListener(this);
		seekBar = findViewById(R.id.dialog_player_seek);
		downloadButton = findViewById(R.id.dialog_player_download);
		seekBar.setOnSeekBarChangeListener(this);
		playButton = findViewById(R.id.dialog_player_play);
		playButton.setOnClickListener(this);
		downloadButton.setOnClickListener(this);
		timeView = findViewById(R.id.dialog_player_time);
		titleView = findViewById(R.id.dialog_player_title);
		findViewById(R.id.dialog_player_comments).setOnClickListener(this);
		findViewById(R.id.dialog_player_lyric).setOnClickListener(this);
		window.setLayout(- 1, - 2);
		run();
	}

	@Override
	public void onCancel(DialogInterface di)
	{
		release();
	}

	public void play(String path, String title)
	{
		release();
		titleView.setText(title);
		this.title = title;
		downloadButton.setVisibility(View.GONE);
		media = new MediaPlayer();
		try
		{
			media.setLooping(false);
			media.setDataSource(path);
			media.setOnPreparedListener(this);
			media.setOnCompletionListener(this);
			media.prepareAsync();
		}
		catch (Exception e)
		{}
		String fileName = new File(path).getName();
		musicId = Long.parseLong(fileName.substring(0, fileName.indexOf("_")));
		musicUrl = null;
	}

	String musicUrl;
	Amus music;

	public void play(String url, Amus amus, String title)
	{
		release();
		titleView.setText(title);
		this.title = title;
		musicUrl = url;
		music = amus;
		musicId = amus.id;
		downloadButton.setVisibility(View.VISIBLE);
		media = new MediaPlayer();
		try
		{
			media.setLooping(false);
			media.setDataSource(getContext(), Uri.parse(url));
			media.setOnPreparedListener(this);
			media.setOnCompletionListener(this);
			media.prepareAsync();
		}
		catch (Exception e)
		{}

	}

	@Override
	public void onPrepared(MediaPlayer media)
	{
		int duration = media.getDuration();
		seekBar.setMax(duration);
		seekBar.setProgress(0);
		media.seekTo(0);
		media.start();
	}

	@Override
	public void onProgressChanged(SeekBar seekBar, int progress, boolean isTouch)
	{
	}

	@Override
	public void onStartTrackingTouch(SeekBar seekBar)
	{
	}

	@Override
	public void onStopTrackingTouch(SeekBar seekBar)
	{
		media.seekTo(seekBar.getProgress());
	}

	@Override
	public void onClick(View view)
	{
		int id = view.getId();
		if (id == R.id.dialog_player_play)
		{
			if (media.isPlaying())
			{
				media.pause();
			} else
			{
				media.start();
			}
			return;
		}
		if (id == R.id.dialog_player_download)
		{
			try
			{
				DownloadManager downloadManager = getContext().getSystemService(DownloadManager.class);
				DownloadManager.Request request = new DownloadManager.Request(Uri.parse(this.musicUrl));
				try
				{
					request.setDestinationInExternalPublicDir("Download/muxivip", URLEncoder.encode(new StringBuffer().append(new StringBuffer().append(new StringBuffer().append(this.music.id).append("_").toString()).append(URLEncoder.encode(this.music.name, "utf-8")).toString()).append(".mp3").toString(), "utf-8"));
				}
				catch (Exception e)
				{
				}
				request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
				request.setVisibleInDownloadsUi(true);
				request.setTitle(title);
				downloadManager.enqueue(request);
				MainActivity.shouldReload = true;
			}
			catch (Exception e)
			{}
			return;
		}
		if (id == R.id.dialog_player_comments)
		{
			new CommentsDialog(activity, musicId).show();
			return;
		}
		if (id == R.id.dialog_player_lyric)
		{
			new LyricDialog(activity, musicId).show();
			return;
		}
	}

	public void release()
	{
		try
		{
			media.release();
			media = null;
		}
		catch (Exception e)
		{}
	}

	@Override
	public void onCompletion(MediaPlayer media)
	{
		if (seekBar.getProgress() == 0) return;
		if (MainActivity.playPosition == - 1) return;
		SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getContext());
		if (settings.getBoolean("one_loop", false))
		{
			media.seekTo(0);
			media.start();
		} else
		{
			int position = MainActivity.playPosition;
			position ++;
			if (position >= MainActivity.plays.length)
			{
				position = 0;
			}
			MainActivity.self.playMusic(position);
		}
	}

	@Override
	public void run()
	{
		if (! running) return;
		try
		{
			int current = media.getCurrentPosition(), duration = media.getDuration();
			if (!seekBar.isPressed()) seekBar.setProgress(current);
			timeView.setText(String.format("%s/%s", current / 1000, duration / 1000));
			if (media.isPlaying())
			{
				playButton.setImageResource(R.drawable.ic_pause);
			} else
			{
				playButton.setImageResource(R.drawable.ic_play);
			}
		}
		catch (Exception e)
		{}
		new Handler().postDelayed(this, 100);
	}
}
