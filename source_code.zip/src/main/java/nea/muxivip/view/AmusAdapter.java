package nea.muxivip.view;
import android.widget.*;
import nea.muxivip.api.*;
import android.content.*;
import android.view.*;
import nea.muxivip.*;
import android.app.*;

public class AmusAdapter extends ArrayAdapter<Amus>
{
	public AmusAdapter (Context context)
	{
		super (context, R.layout.item_amus);
	}

	@Override
	public View getView(int position, View view, ViewGroup parent)
	{
		Activity activity = (Activity) getContext();
		if (view == null)
		{
			view = activity.getLayoutInflater().inflate(R.layout.item_amus, parent, false);
		}
		Amus item = getItem(position);
		TextView nameView = view.findViewById(R.id.item_amus_name);
		TextView authorView = view.findViewById(R.id.item_amus_author);
		nameView.setText(item.name);
		authorView.setText(item.author);
		return view;
	}
}
