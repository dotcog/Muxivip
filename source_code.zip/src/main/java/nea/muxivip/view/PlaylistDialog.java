package nea.muxivip.view;
import android.app.*;
import nea.muxivip.ui.*;
import nea.muxivip.api.*;
import android.widget.*;
import android.view.*;

public class PlaylistDialog extends Dialog
implements Runnable, AdapterView.OnItemClickListener
{
	Activity activiy;
	long playlistId;
	AmusAdapter adapter;

	public PlaylistDialog (Activity activity, long playlistId, String title)
	{
		super (activity);
		this.activiy = activity;
		this.playlistId = playlistId;
		setTitle(title);
		adapter = new AmusAdapter(activity);
		ListView list = new ListView(activity);
		int padding = (int) (activity.getResources().getDisplayMetrics().density * 8f);
		list.setPadding(padding, 0, padding, 0);
		list.setAdapter(adapter);
		list.setOnItemClickListener(this);
		setContentView(list);
		new Thread(this).start();
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		final Amus music = (Amus) parent.getItemAtPosition(position);
		new ParserDialog(activiy, music).show();
	}
	

	@Override
	public void run()
	{
		Amus[] result = null;
		try
		{
			result = Muxiv.getPlaylist(playlistId);
		}
		catch (Exception e) {}
		final Amus[] finalResult = result;
		activiy.runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					if (finalResult == null)
					{
						cancel();
						return;
					}
					adapter.addAll(finalResult);
				}
			});
	}
}
