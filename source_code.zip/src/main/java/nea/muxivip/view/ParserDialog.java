package nea.muxivip.view;
import android.app.*;
import nea.muxivip.*;
import nea.muxivip.api.*;
import android.content.*;
import android.preference.*;
import nea.muxivip.ui.*;

public class ParserDialog extends ProgressDialog
implements Runnable
{
	Amus amus;
	Activity activity;

	public ParserDialog (Activity activity, Amus amus)
	{
		super (activity);
		this.activity = activity;
		setMessage(activity.getString(R.string.loading));
		this.amus = amus;
		new Thread(this).start();
	}

	@Override
	public void run()
	{
		String url = null;
		try
		{
			SharedPreferences settings = PreferenceManager.getDefaultSharedPreferences(getContext());
			url = amus.getPlay(settings.getString("music_level", "standard"));
		}
		catch (Exception e) {}
		final String finalUrl = url;
		activity.runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					if (! isShowing()) return;
					cancel();
					if (finalUrl != null)
					{
						MainActivity.self.playMusic(finalUrl, amus, amus.name);
					}
				}
			});
	}
}
