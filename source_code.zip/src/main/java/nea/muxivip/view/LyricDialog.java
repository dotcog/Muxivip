package nea.muxivip.view;
import android.app.*;
import nea.muxivip.api.*;
import nea.muxivip.*;

public class LyricDialog extends AlertDialog
implements Runnable
{
	long musicId;
	Activity activity;

	public LyricDialog (Activity activity, long musicId)
	{
		super (activity);
		setTitle(R.string.get_lyric);
		setMessage(activity.getString(R.string.loading));
		this.musicId = musicId;
		this.activity = activity;
		new Thread (this).start();
	}

	@Override
	public void run()
	{
		String lyric = null;
		try
		{
			lyric = Muxiv.getLyric(musicId);
		}
		catch (Exception e) {}
		final String result = lyric;
		activity.runOnUiThread(new Runnable() {

				@Override
				public void run()
				{
					if (result == null)
					{
						cancel();
					}
					else
					{
						setMessage(result);
					}
				}
			});
	}
}
