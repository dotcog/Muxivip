package nea.muxivip.view;

import android.app.*;
import android.view.*;
import android.widget.*;
import nea.muxivip.*;
import nea.muxivip.api.*;
import nea.muxivip.ui.*;

public class CommentsDialog extends Dialog
implements AbsListView.OnScrollListener
{

	Activity activity;
	ArrayAdapter<String> adapter;
	int page = -1;
	Thread searchingThread;
	long musicId;

	public CommentsDialog (Activity activity, long musicId)
	{
		super (activity);
		this.activity = activity;
		setTitle(R.string.get_comments);
		ListView list = new ListView(activity);
		setContentView(list);
		adapter = new ArrayAdapter<String> (activity, R.layout.item_text);
		int padding = (int) (activity.getResources().getDisplayMetrics().density * 8f);
		list.setPadding(padding, 0, padding, 0);
		list.setAdapter(adapter);
		list.setOnScrollListener(this);
		this.musicId = musicId;
		onScrollEnd();
	}

	boolean isEnd;

	public void onScrollEnd()
	{
		page ++;
		searchingThread = new Thread()
		{
			public void run()
			{
				try
				{
					final String[] result = Muxiv.getComments(musicId, page);
					if (searchingThread == this)
					{
						activity.runOnUiThread(new Runnable() {
								@Override
								public void run()
								{
									synchronized (CommentsDialog.this)
									{
										if (result.length == 0)
										{
											isEnd = true;
										}
										else
										{
											adapter.addAll(result);
										}
										searchingThread = null;
									}
								}
							});
					}
				} catch (Exception e)
				{
					synchronized (CommentsDialog.this)
					{
						page --;
						searchingThread = null;
					}
				}

			}
		};
		searchingThread.start();
	}

	@Override
	public void onScroll(AbsListView parent, int firstVisibleItem, int visibleItemCount, int totalItemCount)
	{
		if (firstVisibleItem + visibleItemCount == totalItemCount)
		{
			if (searchingThread == null && ! isEnd) onScrollEnd();
		}
	}

	@Override
	public void onScrollStateChanged(AbsListView p1, int p2)
	{
	}
}
