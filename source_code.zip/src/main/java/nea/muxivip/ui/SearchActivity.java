package nea.muxivip.ui;
import android.app.*;
import android.os.*;
import android.view.*;
import nea.muxivip.*;
import android.widget.*;
import nea.muxivip.view.*;
import android.view.inputmethod.*;
import nea.muxivip.api.*;
import android.content.*;
import java.io.*;
import java.net.*;
import android.net.*;
import android.media.*;

public class SearchActivity extends Activity
implements TextView.OnEditorActionListener, AbsListView.OnScrollListener,
AdapterView.OnItemClickListener
{
	EditText input;
	ListView list;
	AmusAdapter adapter;
	int page;
	Thread searchingThread;
	ProgressBar loadingBar;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		MainActivity.reloadPlayerDialog(this);
		setContentView(R.layout.activity_search);
		input = findViewById(R.id.activity_search_input);
		list = findViewById(R.id.activity_search_list);
		loadingBar = findViewById(R.id.activity_search_loading);
		adapter = new AmusAdapter(this);
		list.setAdapter(adapter);
		list.setOnScrollListener(this);
		list.setOnItemClickListener(this);
		input.setOnEditorActionListener(this);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		final Amus music = (Amus) parent.getItemAtPosition(position);
		new ParserDialog(this, music).show();
	}

	@Override
	public void onScroll(AbsListView parent, int firstVisibleItem, int visibleItemCount, int totalItemCount)
	{
		if (firstVisibleItem + visibleItemCount == totalItemCount)
		{
			if (searchingThread == null && ! isEnd) onScrollEnd();
		}
	}

	@Override
	public void onScrollStateChanged(AbsListView p1, int p2)
	{
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.layout.menu_search, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.menu_search_reload:
				research();
				break;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	@Override
	public boolean onEditorAction(TextView view, int action, KeyEvent event)
	{
		if (action == EditorInfo.IME_ACTION_DONE)
		{
			research();
			return true;
		}
		return false;
	}

	public void research()
	{
		if (input.getText().length() == 0) return;
		page = - 1;
		adapter.clear();
		onScrollEnd();
	}

	boolean isEnd;

	public void onScrollEnd()
	{
		if (input.getText().length() == 0) return;
		page ++;
		loadingBar.setVisibility(View.VISIBLE);
		searchingThread = new Thread()
		{
			public void run()
			{
				Amus[] result = null;
				try
				{
					result = Muxiv.search(input.getText().toString(), page);
				}
				catch (Exception e)
				{
				}
				final Amus[] finalResult = result;
				final Thread self = this;
				runOnUiThread(new Runnable() {
						@Override
						public void run()
						{
							if (self != searchingThread) return;
							if (finalResult != null)
							{
								if (finalResult.length == 0)
								{
									isEnd = true;
								} else
								{
									adapter.addAll(finalResult);
								}
							}
							else
							{
								page --;
							}
							loadingBar.setVisibility(View.GONE);
							searchingThread = null;
						}
					});
			}
		};
		searchingThread.start();
	}
}
