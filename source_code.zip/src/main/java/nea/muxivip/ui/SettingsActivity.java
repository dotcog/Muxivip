package nea.muxivip.ui;
import android.preference.*;
import android.os.*;
import nea.muxivip.*;
import android.content.*;

public class SettingsActivity extends PreferenceActivity
implements SharedPreferences.OnSharedPreferenceChangeListener
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.layout.preference_settings);
	}

	@Override
	public void onSharedPreferenceChanged(SharedPreferences preference, String key)
	{
	}
}
