package nea.muxivip.ui;

import android.app.*;
import android.os.*;
import android.view.*;
import nea.muxivip.*;
import android.content.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import android.content.pm.*;
import android.Manifest;
import nea.muxivip.view.*;
import nea.muxivip.api.*;

public class MainActivity extends Activity
implements Runnable, AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener
{

	public static MainActivity self;
	public static String[] plays;
	public static boolean isLoading = false, shouldReload;
	public static int playPosition = - 1;
	public ListView list;
	public ArrayAdapter<String> adapter;
	public PlayerDialog playerDialog;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		self = this;
		super.onCreate(savedInstanceState);
		setTitle(R.string.downloaded_music);
		if (checkStoragePermission())
		{
			create();
		} else
		{
			requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
		}
	}

	public void create()
	{
		shouldReload = true;
		list = new ListView(this);
		adapter = new ArrayAdapter<String>(this, R.layout.item_text);
		list.setAdapter(adapter);
		list.setOnItemClickListener(this);
		list.setOnItemLongClickListener(this);
		setContentView(list);
	}

	public static String getMuxivipPath()
	{
		return Environment.getExternalStorageDirectory() + "/Download/muxivip/";
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		playMusic(position);
	}

	@Override
	public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		try
		{
			new File(getMuxivipPath() + plays[position]).delete();
			new Thread(this).start();
		}
		catch (Exception e)
		{}
		return true;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.layout.menu_main, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	protected void onStart()
	{
		super.onStart();
		try
		{
			if (playerDialog.activity != this)
			{
				reloadPlayerDialog(this);
			}
		}
		catch (Exception e)
		{
			playerDialog = new PlayerDialog(this);
		}
		if (shouldReload)
		{
			shouldReload = false;
			new Thread(this).start();
		}
	}

	@Override
	public void run()
	{
		if (isLoading) return;
		try
		{
			isLoading = true;
			final String[] plays = new File(getMuxivipPath()).list();
			final String[] names = new String[plays.length];
			for (int i = 0; i < plays.length; i ++)
			{
				try
				{
					String fileName = plays[i];
					String name = URLDecoder.decode(fileName.substring(fileName.indexOf('_') + 1, fileName.length() - 4), "utf-8");
					names[i] = name;
				}
				catch (Exception e)
				{}
			}
			runOnUiThread(new Runnable() {

					@Override
					public void run()
					{
						adapter.clear();
						adapter.addAll(names);
						MainActivity.plays = plays;
						isLoading = false;
					}
				});
		}
		catch (Exception e)
		{
			isLoading = false;
		}
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.menu_main_search:
				startActivity(new Intent(this, SearchActivity.class));
				break;
			case R.id.menu_main_settings:
				startActivity(new Intent(this, SettingsActivity.class));
				break;
			case R.id.menu_main_reload:
				new Thread(this).start();
				break;
			case R.id.menu_main_recommend:
				startActivity(new Intent(this, RecommendActivity.class));
				break;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1)
		{
			if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
			{
				create();
			} else
			{
				finishAndRemoveTask();
			}
		}
	}

	private boolean checkStoragePermission()
	{
		int permission = checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
		return permission == PackageManager.PERMISSION_GRANTED;
	}

	public void playMusic(int position)
	{
		playPosition = position;
		playerDialog.play(getMuxivipPath() + plays[position], adapter.getItem(position));
		playerDialog.show();
	}

	public void playMusic(String url, Amus music, String title)
	{
		playPosition = - 1;
		playerDialog.play(url, music, title);
		playerDialog.show();
	}

	public static void reloadPlayerDialog(Activity activity)
	{
		MainActivity main = self;
		main.playerDialog.running = false;
		main.playerDialog = new PlayerDialog(activity);
	}
}
