package nea.muxivip.ui;
import android.app.*;
import android.os.*;
import android.widget.*;
import nea.muxivip.*;
import android.view.*;
import nea.muxivip.view.*;

public class RecommendActivity extends Activity
implements AdapterView.OnItemClickListener
{

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		MainActivity.reloadPlayerDialog(this);
		ListView list = new ListView(this);
		String[] strs = {"云音乐飙升榜", "云音乐新歌榜", "云音乐热歌榜", "云音乐欧美热歌榜", "抖音排行榜"};
		ArrayAdapter<String> adapter = new ArrayAdapter<String> (this, R.layout.item_text, strs);
		list.setAdapter(adapter);
		list.setOnItemClickListener(this);
		setContentView(list);
	}

	@Override
	public void onItemClick(AdapterView<?> parent, View view, int position, long itemId)
	{
		new PlaylistDialog(this, new long[] {19723756, 3779629, 3778678, 2809513713L, 2250011882L, }[position], parent.getItemAtPosition(position).toString()).show();
	}
}
