package nea.muxivip.api;
import java.io.*;
import java.net.*;
import org.json.*;
import java.security.*;
import java.math.*;

public class Amus implements Serializable
{

	public long id;
	public String name, author;

	public String getPlay (String level) throws Exception
	{
		String url = "https://music.163.com/#/song?id=" + id;
		String apiUrl = "https://api.toubiec.cn/api/get-token.php";
		HttpURLConnection con = (HttpURLConnection) new URL(apiUrl).openConnection();
		con.setRequestMethod("POST");
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
		JSONObject json = new JSONObject(in.readLine());
		String token = json.getString("token");
		in.close();
		apiUrl = "https://api.toubiec.cn/api/music_v1.php";
		con = (HttpURLConnection) new URL(apiUrl).openConnection();
		con.setRequestProperty("authorization", "Bearer " + token);
		con.setRequestMethod("POST");
		con.setDoOutput(true);
		OutputStream out = con.getOutputStream();
		JSONObject outJson = new JSONObject();
		outJson.put("url", url);
		outJson.put("level", level);
		outJson.put("type", "song");
		outJson.put("token", md5(token));
		out.write(outJson.toString().getBytes("utf-8"));
		out.flush();
		out.close();
		in = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
		String line;
		StringBuilder buffer = new StringBuilder();
		while ((line = in.readLine()) != null)
		{
			buffer.append(line);
		}
		json = new JSONObject(buffer.toString());
		in.close();
		return json.getJSONObject("url_info").getString("url");
	}

	public static String md5(String plainText) throws Exception
	{
        byte[] secretBytes;
		MessageDigest md = MessageDigest.getInstance("MD5");
		md.update(plainText.getBytes());
		secretBytes = md.digest();
        StringBuilder md5code = new StringBuilder(new BigInteger(1, secretBytes).toString(16));
        for (int i = 0; i < 32 - md5code.length(); i++)
		{
            md5code.insert(0, "0");
        }
        return md5code.toString();
    }

}
