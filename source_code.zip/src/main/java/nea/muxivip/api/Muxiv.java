package nea.muxivip.api;
import java.util.*;
import java.io.*;
import org.json.*;
import java.net.*;

public class Muxiv
{
	public static Amus[] search (String keyword, int page) throws Exception
	{
		String url = "https://music.163.com/api/search/get/web?csrf_token=hlpretag=&hlposttag=&s=%s&type=1&offset=%s&total=true&limit=20";
		url = String.format(url, URLEncoder.encode(keyword, "utf-8"), page * 20);
		BufferedReader in = new BufferedReader(new InputStreamReader(new URL(url).openStream(), "utf-8"));
		JSONObject json = new JSONObject(in.readLine());
		in.close();
		JSONArray songsJson = json.getJSONObject("result").getJSONArray("songs");
		Amus[] songs = new Amus[songsJson.length()];
		for (int i = 0; i < songs.length; i ++)
		{
			JSONObject amusJson = songsJson.getJSONObject(i);
			Amus amus = toAmus(amusJson);
			songs[i] = amus;
		}
		return songs;
	}

	public static Amus[] getPlaylist (long id) throws Exception
	{
		String url = "https://music.163.com/api/playlist/detail?id=%s";
		url = String.format(url, id);
		BufferedReader in = new BufferedReader(new InputStreamReader(new URL(url).openStream(), "utf-8"));
		JSONObject json = new JSONObject(in.readLine());
		in.close();
		JSONArray songsJson = json.getJSONObject("result").getJSONArray("tracks");
		Amus[] songs = new Amus[songsJson.length()];
		for (int i = 0; i < songs.length; i ++)
		{
			JSONObject amusJson = songsJson.getJSONObject(i);
			Amus amus = toAmus(amusJson);
			songs[i] = amus;
		}
		return songs;
	}

	public static String[] getComments (long id, int page) throws Exception
	{
		String url = "https://music.163.com/api/v1/resource/comments/R_SO_4_%s?offset=%s&limit=20";
		url = String.format(url, id, page * 20);
		BufferedReader in = new BufferedReader(new InputStreamReader(new URL(url).openStream(), "utf-8"));
		JSONObject json = new JSONObject(in.readLine());
		in.close();
		JSONArray commentsJson = json.getJSONArray("comments");
		String[] result = new String[commentsJson.length()];
		for (int i = 0; i < result.length; i ++)
		{
			JSONObject commentJson = commentsJson.getJSONObject(i);
			result[i] = "<_> " + commentJson.getJSONObject("user").getString("nickname") + ":\n" + commentJson.getString("content");
		}
		return result;
	}

	public static String getLyric (long id) throws Exception
	{
		String url = "https://music.163.com/api/song/lyric?os=pc&id=%s&lv=-1&tv=-1";
		url = String.format(url, id);
		BufferedReader in = new BufferedReader(new InputStreamReader(new URL(url).openStream(), "utf-8"));
		JSONObject json = new JSONObject(in.readLine());
		in.close();
		String result = json.getJSONObject("lrc").getString("lyric");
		try
		{
			result += "\n\n" + json.getJSONObject("tlyric").getString("lyric");
		}
		catch (Exception e) {}
		return result;
	}

	public static Amus toAmus (JSONObject amusJson) throws Exception
	{
		Amus amus = new Amus();
		amus.id = amusJson.getLong("id");
		amus.name = amusJson.getString("name");
		JSONArray artistsJson = amusJson.getJSONArray("artists");
		StringBuilder buffer = new StringBuilder();
		int len = artistsJson.length();
		for (int j = 0; j < len; j ++)
		{
			buffer.append(artistsJson.getJSONObject(j).getString("name"));
			if (j == len - 1) break;
			buffer.append(", ");
		}
		amus.author = buffer.toString();
		return amus;
	}

	public static Amus shareTextToAmus (String shareText) throws Exception
	{
		Amus amus = new Amus();
		String target = "http://163cn.tv/";
		shareText = shareText.substring(shareText.indexOf(target));
		shareText = shareText.split(" ")[0];
		URLConnection con = new URL(shareText).openConnection();
		con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13; PJU110 Build/TP1A.220905.001) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.129 Mobile Safari/537.36");
		con.setDoInput(false);
		con = new URL(con.getHeaderField("Location")).openConnection();
		BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
		String line;
		target = "window.REDUX_STATE = ";
		while ((line = reader.readLine()) != null)
		{
			line = line.trim();
			if (line.startsWith(target))
			{
				line = line.substring(target.length());
				JSONObject json = new JSONObject(line);
				JSONObject songJson = json.getJSONObject("Song");
				amus.id = songJson.getLong("id");
				amus.name = songJson.getString("name");
				break;
			}
		}
		reader.close();
		return amus;
	}
}
